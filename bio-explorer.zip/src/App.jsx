import { useState } from "react";
import Sidebar from "./components/Sidebar";
import InfoPanel from "./components/InfoPanel";
import CellModel from "./components/CellModel";
import TissueViewer from "./components/TissueViewer";
import HumanBody from "./components/HumanBody";

export default function App() {
  const [mode, setMode] = useState("cell");
  const [selected, setSelected] = useState(null);

  return (
    <div className="flex h-screen bg-slate-950 text-white">
      <Sidebar mode={mode} setMode={setMode} />

      <div className="flex-1">
        {mode === "cell" && <CellModel onSelect={setSelected} />}
        {mode === "tissue" && <TissueViewer onSelect={setSelected} />}
        {mode === "body" && <HumanBody onSelect={setSelected} />}
      </div>

      <InfoPanel data={selected} />
    </div>
  );
}