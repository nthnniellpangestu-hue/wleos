import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import { useRef } from "react";

function FloatingPlane({ position, color, data, onSelect }) {
  const ref = useRef();

  useFrame((state) => {
    if (ref.current) {
      ref.current.position.y = position[1] + Math.sin(state.clock.elapsedTime) * 0.1;
    }
  });

  return (
    <mesh
      ref={ref}
      position={position}
      onClick={() => onSelect(data)}
    >
      <planeGeometry args={[2, 2]} />
      <meshStandardMaterial color={color} />
    </mesh>
  );
}

export default function TissueViewer({ onSelect }) {
  return (
    <Canvas camera={{ position: [0, 0, 5] }}>
      <ambientLight />

      <FloatingPlane
        position={[-1.5, 0, 0]}
        color="lightblue"
        onSelect={onSelect}
        data={{
          name: "Epithelial Tissue",
          function: "Protects surfaces",
          fact: "Found in skin",
        }}
      />

      <FloatingPlane
        position={[1.5, 0, 0]}
        color="red"
        onSelect={onSelect}
        data={{
          name: "Muscle Tissue",
          function: "Enables movement",
          fact: "Contracts and relaxes",
        }}
      />

      <OrbitControls />
    </Canvas>
  );
}