import { Canvas } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import { useState } from "react";

function Organel({ position, color, data, onSelect }) {
  const [hovered, setHovered] = useState(false);

  return (
    <mesh
      position={position}
      onClick={() => onSelect(data)}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      <sphereGeometry args={[0.4, 16, 16]} />
      <meshStandardMaterial color={hovered ? "hotpink" : color} emissive={hovered ? "hotpink" : "black"} />
    </mesh>
  );
}

export default function CellModel({ onSelect }) {
  return (
    <Canvas camera={{ position: [3, 3, 3] }}>
      <ambientLight />
      <pointLight position={[10, 10, 10]} />

      {/* Cell membrane */}
      <mesh>
        <sphereGeometry args={[2, 32, 32]} />
        <meshStandardMaterial wireframe color="cyan" />
      </mesh>

      {/* Organelles */}
      <Organel
        position={[0, 0, 0]}
        color="purple"
        onSelect={onSelect}
        data={{
          name: "Nucleus",
          function: "Controls cell activities",
          fact: "Contains DNA",
        }}
      />

      <Organel
        position={[1, 0.5, -0.5]}
        color="orange"
        onSelect={onSelect}
        data={{
          name: "Mitochondria",
          function: "Produces energy (ATP)",
          fact: "Powerhouse of the cell",
        }}
      />

      <OrbitControls enableZoom />
    </Canvas>
  );
}