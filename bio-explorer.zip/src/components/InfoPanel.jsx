export default function InfoPanel({ data }) {
  return (
    <div className="w-72 bg-slate-900 p-4">
      {!data ? (
        <p className="text-gray-400">Click an object...</p>
      ) : (
        <div>
          <h2 className="text-xl font-bold">{data.name}</h2>
          <p className="mt-2">{data.function}</p>
          <p className="mt-2 text-sm text-gray-400">{data.fact}</p>
        </div>
      )}
    </div>
  );
}