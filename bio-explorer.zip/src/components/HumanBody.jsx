import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import { useRef } from "react";

function Heart({ onSelect }) {
  const ref = useRef();

  useFrame((state) => {
    const scale = 1 + Math.sin(state.clock.elapsedTime * 3) * 0.1;
    if (ref.current) ref.current.scale.set(scale, scale, scale);
  });

  return (
    <mesh
      ref={ref}
      position={[0, 0.5, 0]}
      onClick={() =>
        onSelect({
          name: "Heart",
          function: "Pumps blood",
          fact: "Beats ~100k times/day",
        })
      }
    >
      <sphereGeometry args={[0.4, 16, 16]} />
      <meshStandardMaterial color="red" />
    </mesh>
  );
}

export default function HumanBody({ onSelect }) {
  return (
    <Canvas camera={{ position: [0, 2, 6] }}>
      <ambientLight />

      {/* Body */}
      <mesh>
        <cylinderGeometry args={[1, 1, 3, 32]} />
        <meshStandardMaterial color="gray" />
      </mesh>

      <Heart onSelect={onSelect} />

      <OrbitControls />
    </Canvas>
  );
}