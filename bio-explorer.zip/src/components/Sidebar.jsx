export default function Sidebar({ mode, setMode }) {
  const items = [
    { id: "cell", label: "Cell Explorer" },
    { id: "tissue", label: "Tissue Viewer" },
    { id: "body", label: "Human Body" },
  ];

  return (
    <div className="w-56 bg-slate-900 p-4 space-y-4">
      <h1 className="text-lg font-bold">🧬 Bio Explorer</h1>
      {items.map((item) => (
        <button
          key={item.id}
          onClick={() => setMode(item.id)}
          className={`w-full text-left p-2 rounded ${mode === item.id ? "bg-blue-500" : "bg-slate-800"}`}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}