# 3D Anatomy & Cell Explorer

## Run locally
1. Install Node.js (v18+)
2. Install deps:
   npm install
3. Start dev server:
   npm run dev

Open http://localhost:5173

## Features
- 3D Cell Explorer (click organelles)
- Tissue Viewer (floating layers)
- Human Body (simple + animated heart)