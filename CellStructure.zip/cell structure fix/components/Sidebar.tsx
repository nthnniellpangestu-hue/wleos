'use client'

import { useAppStore, type ViewMode, type CellType, type TissueCategory } from '@/lib/store'
import { cn } from '@/lib/utils'
import organsData from '@/data/organs.json'

const viewModes: { id: ViewMode; label: string; icon: string }[] = [
  { id: 'cell', label: 'Sel 3D', icon: '🧬' },
  { id: 'tissue', label: 'Jaringan', icon: '🧫' },
  { id: 'body', label: 'Tubuh Manusia', icon: '🧍' },
]

export default function Sidebar() {
  const {
    viewMode,
    setViewMode,
    cellType,
    setCellType,
    tissueCategory,
    setTissueCategory,
    selectedSystem,
    setSelectedSystem,
    showLabels,
    toggleLabels,
    isAnimating,
    setIsAnimating,
  } = useAppStore()

  return (
    <aside className="w-72 bg-card border-r border-border flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <h1 className="text-lg font-bold text-foreground">3D Anatomy Explorer</h1>
        <p className="text-xs text-muted-foreground mt-1">Eksplorasi Biologi Interaktif</p>
      </div>

      {/* Navigation */}
      <nav className="p-3">
        <p className="text-xs font-medium text-muted-foreground mb-2 px-1">NAVIGASI</p>
        <div className="flex flex-col gap-1">
          {viewModes.map((mode) => (
            <button
              key={mode.id}
              onClick={() => setViewMode(mode.id)}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all',
                viewMode === mode.id
                  ? 'bg-primary text-primary-foreground'
                  : 'text-foreground hover:bg-secondary'
              )}
            >
              <span className="text-base">{mode.icon}</span>
              <span className="font-medium">{mode.label}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* Context-specific controls */}
      <div className="flex-1 overflow-y-auto p-3 border-t border-border">
        {viewMode === 'cell' && (
          <CellControls cellType={cellType} setCellType={setCellType} />
        )}
        {viewMode === 'tissue' && (
          <TissueControls tissueCategory={tissueCategory} setTissueCategory={setTissueCategory} />
        )}
        {viewMode === 'body' && (
          <BodyControls selectedSystem={selectedSystem} setSelectedSystem={setSelectedSystem} />
        )}
      </div>

      {/* Settings */}
      <div className="p-3 border-t border-border">
        <p className="text-xs font-medium text-muted-foreground mb-2 px-1">PENGATURAN</p>
        <div className="flex flex-col gap-2">
          <label className="flex items-center justify-between px-3 py-2 rounded-lg bg-secondary/50 cursor-pointer">
            <span className="text-sm text-foreground">Tampilkan Label</span>
            <button
              onClick={toggleLabels}
              className={cn(
                'w-10 h-5 rounded-full transition-colors relative',
                showLabels ? 'bg-primary' : 'bg-muted'
              )}
            >
              <span
                className={cn(
                  'absolute top-0.5 w-4 h-4 rounded-full bg-foreground transition-transform',
                  showLabels ? 'translate-x-5' : 'translate-x-0.5'
                )}
              />
            </button>
          </label>
          
          <label className="flex items-center justify-between px-3 py-2 rounded-lg bg-secondary/50 cursor-pointer">
            <span className="text-sm text-foreground">Animasi</span>
            <button
              onClick={() => setIsAnimating(!isAnimating)}
              className={cn(
                'w-10 h-5 rounded-full transition-colors relative',
                isAnimating ? 'bg-primary' : 'bg-muted'
              )}
            >
              <span
                className={cn(
                  'absolute top-0.5 w-4 h-4 rounded-full bg-foreground transition-transform',
                  isAnimating ? 'translate-x-5' : 'translate-x-0.5'
                )}
              />
            </button>
          </label>
        </div>
      </div>

      {/* Instructions */}
      <div className="p-3 border-t border-border">
        <div className="bg-secondary/30 rounded-lg p-3">
          <p className="text-xs font-medium text-foreground mb-2">Cara Menggunakan:</p>
          <ul className="text-xs text-muted-foreground space-y-1">
            <li>• Drag untuk memutar</li>
            <li>• Scroll untuk zoom</li>
            <li>• Klik objek untuk detail</li>
          </ul>
        </div>
      </div>
    </aside>
  )
}

function CellControls({ cellType, setCellType }: { cellType: CellType; setCellType: (type: CellType) => void }) {
  return (
    <div>
      <p className="text-xs font-medium text-muted-foreground mb-2 px-1">TIPE SEL</p>
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => setCellType('animal')}
          className={cn(
            'px-3 py-3 rounded-lg text-sm font-medium transition-all flex flex-col items-center gap-1',
            cellType === 'animal'
              ? 'bg-primary text-primary-foreground'
              : 'bg-secondary text-foreground hover:bg-secondary/80'
          )}
        >
          <span className="text-xl">🐾</span>
          <span>Sel Hewan</span>
        </button>
        <button
          onClick={() => setCellType('plant')}
          className={cn(
            'px-3 py-3 rounded-lg text-sm font-medium transition-all flex flex-col items-center gap-1',
            cellType === 'plant'
              ? 'bg-primary text-primary-foreground'
              : 'bg-secondary text-foreground hover:bg-secondary/80'
          )}
        >
          <span className="text-xl">🌱</span>
          <span>Sel Tumbuhan</span>
        </button>
      </div>
      
      <div className="mt-4 p-3 bg-secondary/30 rounded-lg">
        <p className="text-xs text-muted-foreground">
          {cellType === 'animal' 
            ? 'Sel hewan tidak memiliki dinding sel dan kloroplas, tetapi memiliki lisosom dan sentrosom.'
            : 'Sel tumbuhan memiliki dinding sel, kloroplas, dan vakuola besar yang tidak ada di sel hewan.'
          }
        </p>
      </div>
    </div>
  )
}

function TissueControls({ tissueCategory, setTissueCategory }: { tissueCategory: TissueCategory; setTissueCategory: (category: TissueCategory) => void }) {
  return (
    <div>
      <p className="text-xs font-medium text-muted-foreground mb-2 px-1">KATEGORI JARINGAN</p>
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => setTissueCategory('animal')}
          className={cn(
            'px-3 py-3 rounded-lg text-sm font-medium transition-all flex flex-col items-center gap-1',
            tissueCategory === 'animal'
              ? 'bg-primary text-primary-foreground'
              : 'bg-secondary text-foreground hover:bg-secondary/80'
          )}
        >
          <span className="text-xl">🦴</span>
          <span>Hewan</span>
        </button>
        <button
          onClick={() => setTissueCategory('plant')}
          className={cn(
            'px-3 py-3 rounded-lg text-sm font-medium transition-all flex flex-col items-center gap-1',
            tissueCategory === 'plant'
              ? 'bg-primary text-primary-foreground'
              : 'bg-secondary text-foreground hover:bg-secondary/80'
          )}
        >
          <span className="text-xl">🌿</span>
          <span>Tumbuhan</span>
        </button>
      </div>
      
      <div className="mt-4 p-3 bg-secondary/30 rounded-lg">
        <p className="text-xs text-muted-foreground">
          {tissueCategory === 'animal' 
            ? 'Jaringan hewan terdiri dari jaringan epitel, ikat, otot, dan saraf.'
            : 'Jaringan tumbuhan meliputi meristem, epidermis, parenkim, kolenkim, sklerenkim, xilem, dan floem.'
          }
        </p>
      </div>
    </div>
  )
}

function BodyControls({ selectedSystem, setSelectedSystem }: { selectedSystem: string; setSelectedSystem: (system: string) => void }) {
  return (
    <div>
      <p className="text-xs font-medium text-muted-foreground mb-2 px-1">SISTEM TUBUH</p>
      <div className="flex flex-col gap-1 max-h-80 overflow-y-auto pr-1">
        {organsData.systems.map((system) => (
          <button
            key={system.id}
            onClick={() => setSelectedSystem(system.id)}
            className={cn(
              'flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all text-left',
              selectedSystem === system.id
                ? 'bg-primary text-primary-foreground'
                : 'bg-secondary/50 text-foreground hover:bg-secondary'
            )}
          >
            <span
              className="w-3 h-3 rounded-full flex-shrink-0"
              style={{ backgroundColor: system.color }}
            />
            <span className="font-medium truncate">{system.name}</span>
          </button>
        ))}
      </div>
    </div>
  )
}
