'use client'

import { useAppStore } from '@/lib/store'
import { cn } from '@/lib/utils'
import { X } from 'lucide-react'

export default function InfoPanel() {
  const { selectedInfo, setSelectedInfo, viewMode } = useAppStore()

  if (!selectedInfo) {
    return (
      <aside className="w-80 bg-card border-l border-border flex flex-col h-full">
        <div className="flex-1 flex items-center justify-center p-6">
          <div className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-secondary/50 flex items-center justify-center">
              <span className="text-2xl">
                {viewMode === 'cell' ? '🔬' : viewMode === 'tissue' ? '🧬' : '🫀'}
              </span>
            </div>
            <h3 className="text-sm font-medium text-foreground mb-2">Pilih Objek</h3>
            <p className="text-xs text-muted-foreground">
              Klik pada{' '}
              {viewMode === 'cell'
                ? 'organel sel'
                : viewMode === 'tissue'
                ? 'lapisan jaringan'
                : 'organ'}
              {' '}untuk melihat informasi detail.
            </p>
          </div>
        </div>
      </aside>
    )
  }

  return (
    <aside className="w-80 bg-card border-l border-border flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div 
        className="p-4 border-b border-border relative"
        style={{ 
          background: `linear-gradient(135deg, ${selectedInfo.color}15 0%, transparent 50%)` 
        }}
      >
        <button
          onClick={() => setSelectedInfo(null)}
          className="absolute top-3 right-3 p-1.5 rounded-lg hover:bg-secondary/80 transition-colors"
        >
          <X className="w-4 h-4 text-muted-foreground" />
        </button>
        
        <div className="flex items-start gap-3">
          <div
            className="w-10 h-10 rounded-lg flex items-center justify-center"
            style={{ backgroundColor: `${selectedInfo.color}30` }}
          >
            <div
              className="w-5 h-5 rounded-full"
              style={{ backgroundColor: selectedInfo.color }}
            />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-lg font-bold text-foreground leading-tight">
              {selectedInfo.name}
            </h2>
            {selectedInfo.nameEn && (
              <p className="text-xs text-muted-foreground italic">
                {selectedInfo.nameEn}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Function */}
        {selectedInfo.function && (
          <InfoSection title="Fungsi" color={selectedInfo.color}>
            <p className="text-sm text-foreground leading-relaxed">
              {selectedInfo.function}
            </p>
          </InfoSection>
        )}

        {/* Description */}
        {selectedInfo.description && (
          <InfoSection title="Deskripsi" color={selectedInfo.color}>
            <p className="text-sm text-foreground leading-relaxed">
              {selectedInfo.description}
            </p>
          </InfoSection>
        )}

        {/* How it works */}
        {selectedInfo.howItWorks && (
          <InfoSection title="Cara Kerja" color={selectedInfo.color}>
            <p className="text-sm text-foreground leading-relaxed">
              {selectedInfo.howItWorks}
            </p>
          </InfoSection>
        )}

        {/* Facts */}
        {selectedInfo.facts && selectedInfo.facts.length > 0 && (
          <InfoSection title="Fakta Menarik" color={selectedInfo.color}>
            <ul className="space-y-2">
              {selectedInfo.facts.map((fact, index) => (
                <li key={index} className="flex items-start gap-2 text-sm text-foreground">
                  <span 
                    className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0"
                    style={{ backgroundColor: selectedInfo.color }}
                  />
                  <span className="leading-relaxed">{fact}</span>
                </li>
              ))}
            </ul>
          </InfoSection>
        )}

        {/* Characteristics */}
        {selectedInfo.characteristics && selectedInfo.characteristics.length > 0 && (
          <InfoSection title="Karakteristik" color={selectedInfo.color}>
            <ul className="space-y-2">
              {selectedInfo.characteristics.map((char, index) => (
                <li key={index} className="flex items-start gap-2 text-sm text-foreground">
                  <span 
                    className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0"
                    style={{ backgroundColor: selectedInfo.color }}
                  />
                  <span className="leading-relaxed">{char}</span>
                </li>
              ))}
            </ul>
          </InfoSection>
        )}

        {/* Types */}
        {selectedInfo.types && selectedInfo.types.length > 0 && (
          <InfoSection title="Jenis-Jenis" color={selectedInfo.color}>
            <div className="flex flex-wrap gap-2">
              {selectedInfo.types.map((type, index) => (
                <span
                  key={index}
                  className="px-2 py-1 rounded text-xs font-medium"
                  style={{ 
                    backgroundColor: `${selectedInfo.color}20`,
                    color: selectedInfo.color
                  }}
                >
                  {type}
                </span>
              ))}
            </div>
          </InfoSection>
        )}

        {/* Location */}
        {selectedInfo.location && (
          <InfoSection title="Lokasi" color={selectedInfo.color}>
            <p className="text-sm text-foreground leading-relaxed">
              {selectedInfo.location}
            </p>
          </InfoSection>
        )}
      </div>
    </aside>
  )
}

function InfoSection({ 
  title, 
  color, 
  children 
}: { 
  title: string
  color?: string
  children: React.ReactNode 
}) {
  return (
    <div className="bg-secondary/30 rounded-lg p-3">
      <h3 
        className="text-xs font-semibold uppercase tracking-wide mb-2"
        style={{ color: color || 'var(--muted-foreground)' }}
      >
        {title}
      </h3>
      {children}
    </div>
  )
}
