'use client'

import { Suspense } from 'react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Environment, Stars } from '@react-three/drei'
import { useAppStore } from '@/lib/store'
import CellModel from './CellModel'
import TissueViewer from './TissueViewer'
import HumanBody from './HumanBody'

function SceneContent() {
  const { viewMode } = useAppStore()

  return (
    <>
      {viewMode === 'cell' && <CellModel />}
      {viewMode === 'tissue' && <TissueViewer />}
      {viewMode === 'body' && <HumanBody />}
    </>
  )
}

function LoadingFallback() {
  return (
    <mesh>
      <sphereGeometry args={[0.5, 16, 16]} />
      <meshStandardMaterial color="#00d4ff" wireframe />
    </mesh>
  )
}

export default function Scene() {
  const { viewMode } = useAppStore()

  // Adjust camera position based on view mode
  const getCameraPosition = (): [number, number, number] => {
    switch (viewMode) {
      case 'cell':
        return [0, 0, 8]
      case 'tissue':
        return [0, 0, 6]
      case 'body':
        return [0, 1, 6]
      default:
        return [0, 0, 8]
    }
  }

  return (
    <div className="w-full h-full bg-background relative">
      {/* Gradient overlay */}
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-transparent to-background/50 z-10" />
      
      {/* Canvas */}
      <Canvas
        camera={{ position: getCameraPosition(), fov: 50 }}
        gl={{ antialias: true, alpha: true }}
        dpr={[1, 2]}
      >
        {/* Lighting */}
        <ambientLight intensity={0.4} />
        <directionalLight position={[10, 10, 5]} intensity={0.8} />
        <directionalLight position={[-10, -10, -5]} intensity={0.3} color="#a855f7" />
        <pointLight position={[0, 5, 0]} intensity={0.5} color="#00d4ff" />
        
        {/* Environment */}
        <Stars radius={100} depth={50} count={2000} factor={4} saturation={0} fade speed={0.5} />
        
        {/* Content */}
        <Suspense fallback={<LoadingFallback />}>
          <SceneContent />
        </Suspense>
        
        {/* Controls */}
        <OrbitControls
          enablePan={true}
          enableZoom={true}
          enableRotate={true}
          minDistance={3}
          maxDistance={15}
          autoRotate={false}
          makeDefault
        />
      </Canvas>

      {/* View mode indicator */}
      <div className="absolute bottom-4 left-4 z-20">
        <div className="bg-card/80 backdrop-blur-sm border border-border rounded-lg px-3 py-2">
          <p className="text-xs text-muted-foreground">Mode:</p>
          <p className="text-sm font-medium text-foreground">
            {viewMode === 'cell' ? 'Sel 3D Explorer' : viewMode === 'tissue' ? 'Tissue Viewer' : 'Human Body Systems'}
          </p>
        </div>
      </div>
    </div>
  )
}
