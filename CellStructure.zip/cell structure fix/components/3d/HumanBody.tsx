'use client'

import { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html } from '@react-three/drei'
import * as THREE from 'three'
import { useAppStore } from '@/lib/store'
import organsData from '@/data/organs.json'
import React from 'react'

interface OrganProps {
  organ: {
    id: string
    name: string
    function: string
    howItWorks: string
    position: number[]
  }
  systemColor: string
  isHovered: boolean
  isSelected: boolean
  onHover: (id: string | null) => void
  onClick: () => void
  systemId: string
}

function Organ({ organ, systemColor, isHovered, isSelected, onHover, onClick, systemId }: OrganProps) {
  const meshRef = useRef<THREE.Mesh>(null)
  const glowRef = useRef<THREE.Mesh>(null)
  const { isAnimating } = useAppStore()
  
  useFrame((state) => {
    if (!meshRef.current) return
    
    // Animate specific organs
    if (isAnimating) {
      if (organ.id === 'heart') {
        // Heartbeat animation
        const beat = Math.sin(state.clock.elapsedTime * 4) * 0.05 + 1
        meshRef.current.scale.setScalar(beat)
      } else if (organ.id === 'lungs') {
        // Breathing animation
        const breath = Math.sin(state.clock.elapsedTime * 1.5) * 0.1 + 1
        meshRef.current.scale.set(breath, 1, breath)
      }
    }
    
    // Glow pulse
    if (glowRef.current && (isHovered || isSelected)) {
      const pulse = Math.sin(state.clock.elapsedTime * 3) * 0.1 + 1.3
      glowRef.current.scale.setScalar(pulse)
    }
  })

  const getOrganGeometry = () => {
    switch (organ.id) {
      case 'skull':
      case 'brain':
        return <sphereGeometry args={[0.35, 32, 32]} />
      case 'heart':
        return <sphereGeometry args={[0.2, 16, 16]} />
      case 'lungs':
        return <capsuleGeometry args={[0.25, 0.4, 8, 16]} />
      case 'stomach':
      case 'bladder':
        return <sphereGeometry args={[0.18, 16, 16]} />
      case 'liver':
      case 'spleen':
        return <dodecahedronGeometry args={[0.22, 0]} />
      case 'kidneys':
        return <capsuleGeometry args={[0.1, 0.15, 8, 16]} />
      case 'small_intestine':
      case 'large_intestine':
        return <torusGeometry args={[0.2, 0.08, 8, 24]} />
      case 'spine':
      case 'spinal_cord':
        return <cylinderGeometry args={[0.08, 0.08, 1.5, 8]} />
      case 'ribcage':
        return <torusGeometry args={[0.35, 0.05, 8, 24]} />
      case 'thyroid':
      case 'thymus':
      case 'adrenal':
      case 'pituitary':
        return <sphereGeometry args={[0.1, 12, 12]} />
      case 'trachea':
      case 'esophagus':
        return <cylinderGeometry args={[0.05, 0.05, 0.5, 8]} />
      case 'nose':
        return <coneGeometry args={[0.08, 0.15, 8]} />
      case 'diaphragm':
        return <cylinderGeometry args={[0.4, 0.4, 0.05, 16]} />
      default:
        return <sphereGeometry args={[0.15, 16, 16]} />
    }
  }

  const getOrganPosition = (): [number, number, number] => {
    // Adjust positions for different organs
    const base = organ.position as [number, number, number]
    
    // Add slight offset based on organ type for better visibility
    if (organ.id === 'kidneys') {
      return [base[0] + 0.3, base[1], base[2]]
    }
    if (organ.id.includes('intestine')) {
      return [base[0], base[1], base[2] + 0.1]
    }
    
    return base
  }

  return (
    <group position={getOrganPosition()}>
      {/* Glow effect */}
      {(isHovered || isSelected) && (
        <mesh ref={glowRef} scale={1.3}>
          {getOrganGeometry()}
          <meshBasicMaterial
            color={systemColor}
            transparent
            opacity={0.3}
            side={THREE.BackSide}
          />
        </mesh>
      )}
      
      {/* Main organ */}
      <mesh
        ref={meshRef}
        onPointerOver={(e) => {
          e.stopPropagation()
          onHover(organ.id)
          document.body.style.cursor = 'pointer'
        }}
        onPointerOut={() => {
          onHover(null)
          document.body.style.cursor = 'default'
        }}
        onClick={(e) => {
          e.stopPropagation()
          onClick()
        }}
      >
        {getOrganGeometry()}
        <meshStandardMaterial
          color={systemColor}
          emissive={systemColor}
          emissiveIntensity={isHovered || isSelected ? 0.5 : 0.15}
          roughness={0.4}
          metalness={0.2}
        />
      </mesh>
    </group>
  )
}

function OrganLabel({ organ, show }: { organ: { id: string; name: string; position: number[] }; show: boolean }) {
  if (!show) return null
  
  return (
    <Html
      position={[organ.position[0] + 0.5, organ.position[1], organ.position[2]]}
      center
      style={{
        pointerEvents: 'none',
        userSelect: 'none',
      }}
    >
      <div className="bg-card/90 backdrop-blur-sm px-2 py-1 rounded text-xs text-foreground whitespace-nowrap border border-border">
        {organ.name}
      </div>
    </Html>
  )
}

function BodyOutline() {
  const outlineRef = useRef<THREE.Group>(null)
  
  useFrame((state) => {
    if (outlineRef.current) {
      outlineRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.2) * 0.05
    }
  })

  return (
    <group ref={outlineRef}>
      {/* Head */}
      <mesh position={[0, 2.8, 0]}>
        <sphereGeometry args={[0.4, 32, 32]} />
        <meshStandardMaterial color="#2a2a4a" transparent opacity={0.3} wireframe />
      </mesh>
      
      {/* Torso */}
      <mesh position={[0, 1.5, 0]}>
        <capsuleGeometry args={[0.5, 1.5, 8, 16]} />
        <meshStandardMaterial color="#2a2a4a" transparent opacity={0.2} wireframe />
      </mesh>
      
      {/* Pelvis */}
      <mesh position={[0, 0, 0]}>
        <sphereGeometry args={[0.45, 16, 16]} />
        <meshStandardMaterial color="#2a2a4a" transparent opacity={0.2} wireframe />
      </mesh>
      
      {/* Arms */}
      <mesh position={[0.8, 1.6, 0]} rotation={[0, 0, -0.3]}>
        <capsuleGeometry args={[0.1, 1, 8, 8]} />
        <meshStandardMaterial color="#2a2a4a" transparent opacity={0.15} wireframe />
      </mesh>
      <mesh position={[-0.8, 1.6, 0]} rotation={[0, 0, 0.3]}>
        <capsuleGeometry args={[0.1, 1, 8, 8]} />
        <meshStandardMaterial color="#2a2a4a" transparent opacity={0.15} wireframe />
      </mesh>
      
      {/* Legs */}
      <mesh position={[0.25, -1, 0]}>
        <capsuleGeometry args={[0.12, 1.2, 8, 8]} />
        <meshStandardMaterial color="#2a2a4a" transparent opacity={0.15} wireframe />
      </mesh>
      <mesh position={[-0.25, -1, 0]}>
        <capsuleGeometry args={[0.12, 1.2, 8, 8]} />
        <meshStandardMaterial color="#2a2a4a" transparent opacity={0.15} wireframe />
      </mesh>
    </group>
  )
}

function BloodFlow() {
  const particlesRef = useRef<THREE.Points>(null)
  const { selectedSystem, isAnimating } = useAppStore()
  
  const particles = useMemo(() => {
    const count = 100
    const positions = new Float32Array(count * 3)
    
    for (let i = 0; i < count; i++) {
      const t = i / count
      // Create a path through the body
      positions[i * 3] = Math.sin(t * Math.PI * 4) * 0.3
      positions[i * 3 + 1] = t * 3 - 0.5
      positions[i * 3 + 2] = Math.cos(t * Math.PI * 4) * 0.2
    }
    
    return positions
  }, [])

  useFrame((state) => {
    if (particlesRef.current && selectedSystem === 'circulatory' && isAnimating) {
      const positions = particlesRef.current.geometry.attributes.position.array as Float32Array
      const count = positions.length / 3
      
      for (let i = 0; i < count; i++) {
        positions[i * 3 + 1] -= 0.02
        if (positions[i * 3 + 1] < -0.5) {
          positions[i * 3 + 1] = 2.5
        }
      }
      
      particlesRef.current.geometry.attributes.position.needsUpdate = true
    }
  })

  if (selectedSystem !== 'circulatory') return null

  return (
    <points ref={particlesRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[particles, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.05}
        color="#ff4444"
        transparent
        opacity={0.8}
        sizeAttenuation
      />
    </points>
  )
}

export default function HumanBody() {
  const { selectedSystem, setSelectedInfo, hoveredItem, setHoveredItem, showLabels } = useAppStore()
  const [selectedOrganId, setSelectedOrganId] = React.useState<string | null>(null)
  
  const currentSystem = organsData.systems.find(s => s.id === selectedSystem)

  const handleOrganClick = (organ: typeof currentSystem.organs[0]) => {
    setSelectedOrganId(organ.id)
    setSelectedInfo({
      id: organ.id,
      name: organ.name,
      function: organ.function,
      howItWorks: organ.howItWorks,
      color: currentSystem?.color,
    })
  }

  if (!currentSystem) return null

  return (
    <group position={[0, -0.5, 0]}>
      {/* Body outline */}
      <BodyOutline />
      
      {/* Blood flow animation */}
      <BloodFlow />
      
      {/* Organs */}
      {currentSystem.organs.map((organ) => (
        <group key={organ.id}>
          <Organ
            organ={organ}
            systemColor={currentSystem.color}
            isHovered={hoveredItem === organ.id}
            isSelected={selectedOrganId === organ.id}
            onHover={setHoveredItem}
            onClick={() => handleOrganClick(organ)}
            systemId={selectedSystem}
          />
          <OrganLabel organ={organ} show={showLabels} />
        </group>
      ))}
    </group>
  )
}
