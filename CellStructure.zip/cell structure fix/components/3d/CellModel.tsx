'use client'

import { useRef, useState, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html, Float } from '@react-three/drei'
import * as THREE from 'three'
import { useAppStore } from '@/lib/store'
import cellsData from '@/data/cells.json'

interface OrganelleProps {
  organelle: {
    id: string
    name: string
    nameEn: string
    function: string
    facts: string[]
    position: number[]
    color: string
    size: number
  }
  isHovered: boolean
  isSelected: boolean
  onHover: (id: string | null) => void
  onClick: () => void
}

function Organelle({ organelle, isHovered, isSelected, onHover, onClick }: OrganelleProps) {
  const meshRef = useRef<THREE.Mesh>(null)
  const glowRef = useRef<THREE.Mesh>(null)
  
  useFrame((state) => {
    if (meshRef.current) {
      // Subtle floating animation
      meshRef.current.position.y = organelle.position[1] + Math.sin(state.clock.elapsedTime * 0.5 + organelle.position[0]) * 0.05
    }
    if (glowRef.current) {
      // Glow pulse when hovered
      const scale = isHovered ? 1.3 + Math.sin(state.clock.elapsedTime * 3) * 0.1 : 1.2
      glowRef.current.scale.setScalar(scale)
    }
  })

  const getGeometry = () => {
    const id = organelle.id.replace(/[0-9]/g, '')
    
    switch (id) {
      case 'nucleus':
        return <sphereGeometry args={[organelle.size, 32, 32]} />
      case 'mitochondria':
        return <capsuleGeometry args={[organelle.size * 0.4, organelle.size * 1.2, 8, 16]} />
      case 'endoplasmic_reticulum':
        return <torusKnotGeometry args={[organelle.size * 0.4, organelle.size * 0.15, 64, 8]} />
      case 'golgi_apparatus':
        return <torusGeometry args={[organelle.size * 0.5, organelle.size * 0.2, 16, 32]} />
      case 'ribosome':
        return <sphereGeometry args={[organelle.size, 16, 16]} />
      case 'lysosome':
        return <dodecahedronGeometry args={[organelle.size, 0]} />
      case 'centrosome':
        return <cylinderGeometry args={[organelle.size * 0.3, organelle.size * 0.3, organelle.size, 8]} />
      case 'vacuole':
        return <sphereGeometry args={[organelle.size, 32, 32]} />
      case 'chloroplast':
        return <capsuleGeometry args={[organelle.size * 0.5, organelle.size * 0.8, 8, 16]} />
      case 'cell_wall':
      case 'cell_membrane':
        return <sphereGeometry args={[organelle.size, 8, 8]} />
      case 'plasmodesmata':
        return <cylinderGeometry args={[organelle.size, organelle.size, organelle.size * 2, 8]} />
      default:
        return <sphereGeometry args={[organelle.size, 16, 16]} />
    }
  }

  return (
    <group position={organelle.position as [number, number, number]}>
      {/* Glow effect */}
      {(isHovered || isSelected) && (
        <mesh ref={glowRef} scale={1.2}>
          {getGeometry()}
          <meshBasicMaterial
            color={organelle.color}
            transparent
            opacity={0.3}
            side={THREE.BackSide}
          />
        </mesh>
      )}
      
      {/* Main organelle */}
      <mesh
        ref={meshRef}
        onPointerOver={(e) => {
          e.stopPropagation()
          onHover(organelle.id)
          document.body.style.cursor = 'pointer'
        }}
        onPointerOut={() => {
          onHover(null)
          document.body.style.cursor = 'default'
        }}
        onClick={(e) => {
          e.stopPropagation()
          onClick()
        }}
      >
        {getGeometry()}
        <meshStandardMaterial
          color={organelle.color}
          emissive={organelle.color}
          emissiveIntensity={isHovered || isSelected ? 0.5 : 0.1}
          roughness={0.3}
          metalness={0.2}
          transparent={organelle.id.includes('vacuole') || organelle.id.includes('membrane') || organelle.id.includes('wall')}
          opacity={organelle.id.includes('vacuole') ? 0.4 : organelle.id.includes('membrane') || organelle.id.includes('wall') ? 0.2 : 1}
        />
      </mesh>
    </group>
  )
}

function CellMembrane({ isPlant }: { isPlant: boolean }) {
  const membraneRef = useRef<THREE.Mesh>(null)
  
  useFrame((state) => {
    if (membraneRef.current) {
      membraneRef.current.rotation.y = state.clock.elapsedTime * 0.05
    }
  })

  return (
    <group>
      {/* Cell membrane */}
      <mesh ref={membraneRef}>
        <sphereGeometry args={[3, 64, 64]} />
        <meshStandardMaterial
          color="#1abc9c"
          transparent
          opacity={0.15}
          side={THREE.DoubleSide}
          roughness={0.8}
        />
      </mesh>
      
      {/* Cell wall for plant cells */}
      {isPlant && (
        <mesh>
          <boxGeometry args={[6.5, 6.5, 6.5]} />
          <meshStandardMaterial
            color="#a29bfe"
            transparent
            opacity={0.1}
            side={THREE.DoubleSide}
            wireframe
          />
        </mesh>
      )}
    </group>
  )
}

function OrganelleLabel({ organelle, show }: { organelle: { id: string; name: string; position: number[] }; show: boolean }) {
  if (!show) return null
  
  return (
    <Html
      position={[organelle.position[0], organelle.position[1] + 0.5, organelle.position[2]]}
      center
      distanceFactor={8}
      style={{
        pointerEvents: 'none',
        userSelect: 'none',
      }}
    >
      <div className="bg-card/90 backdrop-blur-sm px-2 py-1 rounded text-xs text-foreground whitespace-nowrap border border-border">
        {organelle.name}
      </div>
    </Html>
  )
}

export default function CellModel() {
  const { cellType, setSelectedInfo, hoveredItem, setHoveredItem, showLabels } = useAppStore()
  const [selectedId, setSelectedId] = useState<string | null>(null)
  
  const cellData = cellType === 'animal' ? cellsData.animalCell : cellsData.plantCell

  const handleOrganelleClick = (organelle: typeof cellData.organelles[0]) => {
    setSelectedId(organelle.id)
    setSelectedInfo({
      id: organelle.id,
      name: organelle.name,
      nameEn: organelle.nameEn,
      function: organelle.function,
      facts: organelle.facts,
      color: organelle.color,
    })
  }

  return (
    <Float
      speed={1}
      rotationIntensity={0.2}
      floatIntensity={0.3}
    >
      <group>
        {/* Cell membrane/wall */}
        <CellMembrane isPlant={cellType === 'plant'} />
        
        {/* Organelles */}
        {cellData.organelles.map((organelle) => (
          <group key={organelle.id}>
            <Organelle
              organelle={organelle}
              isHovered={hoveredItem === organelle.id}
              isSelected={selectedId === organelle.id}
              onHover={setHoveredItem}
              onClick={() => handleOrganelleClick(organelle)}
            />
            <OrganelleLabel organelle={organelle} show={showLabels && !organelle.id.includes('membrane') && !organelle.id.includes('wall')} />
          </group>
        ))}

        {/* Ambient particles (cytoplasm effect) */}
        <CytoplasmParticles />
      </group>
    </Float>
  )
}

function CytoplasmParticles() {
  const particlesRef = useRef<THREE.Points>(null)
  
  const particles = useMemo(() => {
    const count = 200
    const positions = new Float32Array(count * 3)
    
    for (let i = 0; i < count; i++) {
      // Random position inside a sphere
      const theta = Math.random() * Math.PI * 2
      const phi = Math.acos(2 * Math.random() - 1)
      const r = Math.random() * 2.8
      
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta)
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta)
      positions[i * 3 + 2] = r * Math.cos(phi)
    }
    
    return positions
  }, [])

  useFrame((state) => {
    if (particlesRef.current) {
      particlesRef.current.rotation.y = state.clock.elapsedTime * 0.02
      particlesRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.01) * 0.1
    }
  })

  return (
    <points ref={particlesRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[particles, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.02}
        color="#00d4ff"
        transparent
        opacity={0.3}
        sizeAttenuation
      />
    </points>
  )
}
