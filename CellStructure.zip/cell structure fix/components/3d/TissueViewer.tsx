'use client'

import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html, RoundedBox } from '@react-three/drei'
import * as THREE from 'three'
import { useAppStore } from '@/lib/store'
import tissuesData from '@/data/tissues.json'

interface TissueLayerProps {
  tissue: {
    id: string
    name: string
    nameEn: string
    description: string
    characteristics: string[]
    types?: string[]
    location: string
    function: string
    color: string
    depth: number
  }
  isHovered: boolean
  isSelected: boolean
  onHover: (id: string | null) => void
  onClick: () => void
  totalLayers: number
}

function TissueLayer({ tissue, isHovered, isSelected, onHover, onClick, totalLayers }: TissueLayerProps) {
  const meshRef = useRef<THREE.Mesh>(null)
  const glowRef = useRef<THREE.Mesh>(null)
  
  const yPosition = (totalLayers / 2 - tissue.depth) * 0.8 - 0.4
  const zOffset = isHovered ? 0.3 : isSelected ? 0.2 : 0
  
  useFrame((state) => {
    if (meshRef.current) {
      // Smooth transition for z position
      meshRef.current.position.z = THREE.MathUtils.lerp(meshRef.current.position.z, zOffset, 0.1)
      
      // Subtle wave animation
      meshRef.current.position.x = Math.sin(state.clock.elapsedTime * 0.5 + tissue.depth) * 0.05
    }
    if (glowRef.current && (isHovered || isSelected)) {
      glowRef.current.position.z = meshRef.current?.position.z ?? 0
    }
  })

  return (
    <group position={[0, yPosition, 0]}>
      {/* Glow effect */}
      {(isHovered || isSelected) && (
        <mesh ref={glowRef} position={[0, 0, zOffset]}>
          <boxGeometry args={[4.4, 0.7, 0.22]} />
          <meshBasicMaterial
            color={tissue.color}
            transparent
            opacity={0.3}
          />
        </mesh>
      )}
      
      {/* Main tissue layer */}
      <RoundedBox
        ref={meshRef}
        args={[4, 0.6, 0.15]}
        radius={0.05}
        smoothness={4}
        onPointerOver={(e) => {
          e.stopPropagation()
          onHover(tissue.id)
          document.body.style.cursor = 'pointer'
        }}
        onPointerOut={() => {
          onHover(null)
          document.body.style.cursor = 'default'
        }}
        onClick={(e) => {
          e.stopPropagation()
          onClick()
        }}
      >
        <meshStandardMaterial
          color={tissue.color}
          emissive={tissue.color}
          emissiveIntensity={isHovered || isSelected ? 0.4 : 0.1}
          roughness={0.4}
          metalness={0.1}
        />
      </RoundedBox>
      
      {/* Texture pattern */}
      <TissuePattern tissue={tissue} yPosition={0} zOffset={zOffset + 0.08} />
    </group>
  )
}

function TissuePattern({ tissue, yPosition, zOffset }: { tissue: { id: string; color: string }; yPosition: number; zOffset: number }) {
  const patternRef = useRef<THREE.Group>(null)
  
  useFrame((state) => {
    if (patternRef.current) {
      patternRef.current.position.z = THREE.MathUtils.lerp(patternRef.current.position.z, zOffset, 0.1)
    }
  })

  const getPattern = () => {
    switch (tissue.id) {
      case 'epithelial':
      case 'epidermis':
        // Grid of cells
        return (
          <group>
            {Array.from({ length: 12 }).map((_, i) => (
              <mesh key={i} position={[(i % 4 - 1.5) * 0.8, Math.floor(i / 4) * 0.15 - 0.15, 0]}>
                <boxGeometry args={[0.6, 0.12, 0.02]} />
                <meshStandardMaterial color={tissue.color} transparent opacity={0.6} />
              </mesh>
            ))}
          </group>
        )
      case 'muscle':
        // Striations
        return (
          <group>
            {Array.from({ length: 8 }).map((_, i) => (
              <mesh key={i} position={[(i - 3.5) * 0.5, 0, 0]}>
                <boxGeometry args={[0.1, 0.5, 0.02]} />
                <meshStandardMaterial color={tissue.color} transparent opacity={0.4} />
              </mesh>
            ))}
          </group>
        )
      case 'nervous':
        // Neural network pattern
        return (
          <group>
            {Array.from({ length: 5 }).map((_, i) => (
              <mesh key={i} position={[(i - 2) * 0.7, Math.sin(i) * 0.1, 0]}>
                <sphereGeometry args={[0.08, 8, 8]} />
                <meshStandardMaterial color={tissue.color} emissive={tissue.color} emissiveIntensity={0.5} />
              </mesh>
            ))}
            {/* Connections */}
            {Array.from({ length: 4 }).map((_, i) => (
              <mesh key={`line-${i}`} position={[(i - 1.5) * 0.7, Math.sin(i + 0.5) * 0.05, 0]} rotation={[0, 0, Math.sin(i) * 0.3]}>
                <boxGeometry args={[0.5, 0.02, 0.01]} />
                <meshStandardMaterial color={tissue.color} transparent opacity={0.6} />
              </mesh>
            ))}
          </group>
        )
      case 'xylem':
      case 'phloem':
        // Tube-like structures
        return (
          <group>
            {Array.from({ length: 6 }).map((_, i) => (
              <mesh key={i} position={[(i - 2.5) * 0.6, 0, 0]}>
                <cylinderGeometry args={[0.08, 0.08, 0.5, 8]} />
                <meshStandardMaterial color={tissue.color} transparent opacity={0.5} />
              </mesh>
            ))}
          </group>
        )
      case 'meristem':
        // Small dividing cells
        return (
          <group>
            {Array.from({ length: 15 }).map((_, i) => (
              <mesh key={i} position={[(i % 5 - 2) * 0.6, (Math.floor(i / 5) - 1) * 0.15, 0]}>
                <sphereGeometry args={[0.1, 8, 8]} />
                <meshStandardMaterial color={tissue.color} transparent opacity={0.5} />
              </mesh>
            ))}
          </group>
        )
      default:
        // Generic dot pattern
        return (
          <group>
            {Array.from({ length: 8 }).map((_, i) => (
              <mesh key={i} position={[(i % 4 - 1.5) * 0.9, Math.floor(i / 4) * 0.2 - 0.1, 0]}>
                <circleGeometry args={[0.15, 16]} />
                <meshStandardMaterial color={tissue.color} transparent opacity={0.3} />
              </mesh>
            ))}
          </group>
        )
    }
  }

  return (
    <group ref={patternRef} position={[0, yPosition, zOffset]}>
      {getPattern()}
    </group>
  )
}

function TissueLabel({ tissue, yPosition, show }: { tissue: { id: string; name: string; depth: number }; yPosition: number; show: boolean }) {
  if (!show) return null
  
  return (
    <Html
      position={[2.5, yPosition, 0]}
      center
      style={{
        pointerEvents: 'none',
        userSelect: 'none',
      }}
    >
      <div className="bg-card/90 backdrop-blur-sm px-2 py-1 rounded text-xs text-foreground whitespace-nowrap border border-border">
        {tissue.name}
      </div>
    </Html>
  )
}

export default function TissueViewer() {
  const { tissueCategory, setSelectedInfo, hoveredItem, setHoveredItem, showLabels } = useAppStore()
  const [selectedId, setSelectedId] = React.useState<string | null>(null)
  
  const tissueData = tissueCategory === 'plant' ? tissuesData.plantTissues : tissuesData.animalTissues
  const tissues = tissueData.tissues

  const handleTissueClick = (tissue: typeof tissues[0]) => {
    setSelectedId(tissue.id)
    setSelectedInfo({
      id: tissue.id,
      name: tissue.name,
      nameEn: tissue.nameEn,
      description: tissue.description,
      characteristics: tissue.characteristics,
      types: tissue.types,
      location: tissue.location,
      function: tissue.function,
      color: tissue.color,
    })
  }

  return (
    <group rotation={[0.2, 0, 0]}>
      {tissues.map((tissue) => {
        const yPosition = (tissues.length / 2 - tissue.depth) * 0.8 - 0.4
        return (
          <group key={tissue.id}>
            <TissueLayer
              tissue={tissue}
              isHovered={hoveredItem === tissue.id}
              isSelected={selectedId === tissue.id}
              onHover={setHoveredItem}
              onClick={() => handleTissueClick(tissue)}
              totalLayers={tissues.length}
            />
            <TissueLabel tissue={tissue} yPosition={yPosition} show={showLabels} />
          </group>
        )
      })}
      
      {/* Container frame */}
      <mesh position={[0, 0, -0.2]}>
        <boxGeometry args={[4.5, tissues.length * 0.8 + 0.5, 0.05]} />
        <meshStandardMaterial color="#1a1a2e" transparent opacity={0.5} />
      </mesh>
    </group>
  )
}

import React from 'react'
