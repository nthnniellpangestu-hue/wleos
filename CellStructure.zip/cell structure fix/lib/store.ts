import { create } from 'zustand'

export type ViewMode = 'cell' | 'tissue' | 'body'
export type CellType = 'animal' | 'plant'
export type TissueCategory = 'plant' | 'animal'

interface SelectedInfo {
  id: string
  name: string
  nameEn?: string
  function?: string
  description?: string
  facts?: string[]
  characteristics?: string[]
  types?: string[]
  location?: string
  howItWorks?: string
  color?: string
}

interface AppState {
  // View mode
  viewMode: ViewMode
  setViewMode: (mode: ViewMode) => void
  
  // Cell explorer
  cellType: CellType
  setCellType: (type: CellType) => void
  
  // Tissue viewer
  tissueCategory: TissueCategory
  setTissueCategory: (category: TissueCategory) => void
  
  // Body systems
  selectedSystem: string
  setSelectedSystem: (system: string) => void
  
  // Selected item info
  selectedInfo: SelectedInfo | null
  setSelectedInfo: (info: SelectedInfo | null) => void
  
  // Hover state
  hoveredItem: string | null
  setHoveredItem: (item: string | null) => void
  
  // Labels toggle
  showLabels: boolean
  toggleLabels: () => void
  
  // Animation states
  isAnimating: boolean
  setIsAnimating: (animating: boolean) => void
}

export const useAppStore = create<AppState>((set) => ({
  // View mode
  viewMode: 'cell',
  setViewMode: (mode) => set({ viewMode: mode, selectedInfo: null, hoveredItem: null }),
  
  // Cell explorer
  cellType: 'animal',
  setCellType: (type) => set({ cellType: type, selectedInfo: null }),
  
  // Tissue viewer
  tissueCategory: 'animal',
  setTissueCategory: (category) => set({ tissueCategory: category, selectedInfo: null }),
  
  // Body systems
  selectedSystem: 'circulatory',
  setSelectedSystem: (system) => set({ selectedSystem: system, selectedInfo: null }),
  
  // Selected item info
  selectedInfo: null,
  setSelectedInfo: (info) => set({ selectedInfo: info }),
  
  // Hover state
  hoveredItem: null,
  setHoveredItem: (item) => set({ hoveredItem: item }),
  
  // Labels toggle
  showLabels: true,
  toggleLabels: () => set((state) => ({ showLabels: !state.showLabels })),
  
  // Animation states
  isAnimating: true,
  setIsAnimating: (animating) => set({ isAnimating: animating }),
}))
