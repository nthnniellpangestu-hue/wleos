'use client'

import dynamic from 'next/dynamic'
import Sidebar from '@/components/Sidebar'
import InfoPanel from '@/components/InfoPanel'

// Dynamic import for 3D scene to avoid SSR issues
const Scene = dynamic(() => import('@/components/3d/Scene'), {
  ssr: false,
  loading: () => (
    <div className="w-full h-full flex items-center justify-center bg-background">
      <div className="text-center">
        <div className="w-12 h-12 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-sm text-muted-foreground">Memuat 3D Scene...</p>
      </div>
    </div>
  ),
})

export default function HomePage() {
  return (
    <main className="h-screen w-screen overflow-hidden flex bg-background">
      {/* Sidebar - Navigation */}
      <Sidebar />
      
      {/* Main 3D Canvas */}
      <div className="flex-1 relative">
        <Scene />
      </div>
      
      {/* Info Panel - Details */}
      <InfoPanel />
    </main>
  )
}
